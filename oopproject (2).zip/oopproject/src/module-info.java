/**
 * 
 */
/**
 * 
 */
module oopproject {
	requires java.desktop;
}