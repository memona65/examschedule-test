package exam.scheduling;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.IOException;

public class SchedulingGUI extends JFrame {
	private static final long serialVersionUID = 1L;
	// Data storage using plain arrays
    private ExamHall[] halls;
    private int hallCount;
    private CourseExam[] exams;
    private int examCount;
    private Constraint[] extraConstraints;   // for preferred slots etc.
    private int constraintCount;
    private ExamSchedule currentSchedule;

    // UI components
    private JTable scheduleTable;
    private DefaultTableModel scheduleModel;
    private JLabel statusLabel;          // will be initialised in initUI()
    private JProgressBar progressBar;  

    public SchedulingGUI() {
    	JPanel topPanel = new JPanel(new BorderLayout());
    	topPanel.setBackground(new Color(245, 248, 250));
    	topPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));

    	ImageIcon logoIcon = null;
    	try {
    	    logoIcon = new ImageIcon("air logo.jpg");
    	    // Scale logo to a reasonable size (e.g., 60x60)
    	    Image scaledImage = logoIcon.getImage().getScaledInstance(60, 60, Image.SCALE_SMOOTH);
    	    logoIcon = new ImageIcon(scaledImage);
    	} catch (Exception e) {
    	    // If logo not found, use a default icon or text
    	    System.err.println("Logo not found: " + e.getMessage());
    	}
    	JLabel logoLabel = new JLabel(logoIcon);
    	logoLabel.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 15));

        setTitle("University Exam Scheduling System");
        topPanel.add(logoLabel, BorderLayout.WEST);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        
        try {
            // Set Nimbus Look and Feel for modern appearance
            UIManager.setLookAndFeel("javax.swing.plaf.nimbus.NimbusLookAndFeel");
            // Customize Nimbus colors (optional)
            UIManager.put("nimbusBase", new Color(50, 90, 150));
            UIManager.put("nimbusBlueGrey", new Color(200, 210, 230));
            UIManager.put("control", new Color(240, 245, 250));
        } catch (Exception e) {
            // fallback to default
        }

        // Initialize arrays
        halls = new ExamHall[200];     // dynamic resizing when needed
        hallCount = 0;
        exams = new CourseExam[50];
        examCount = 0;
        extraConstraints = new Constraint[50];
        constraintCount = 0;

        loadData();
        initUI();
    }

    private void loadData() {
        try {
            ExamHall[] loadedHalls = DataManager.loadHalls();
            if (loadedHalls != null) {
                halls = loadedHalls;
                hallCount = loadedHalls.length;
                // ensure capacity for future additions
                if (halls.length < hallCount + 5) {
                    ExamHall[] newHalls = new ExamHall[hallCount + 10];
                    for (int i = 0; i < hallCount; i++) newHalls[i] = halls[i];
                    halls = newHalls;
                }
            }
            CourseExam[] loadedExams = DataManager.loadExams();
            if (loadedExams != null) {
                exams = loadedExams;
                examCount = loadedExams.length;
                if (exams.length < examCount + 5) {
                    CourseExam[] newExams = new CourseExam[examCount + 10];
                    for (int i = 0; i < examCount; i++) newExams[i] = exams[i];
                    exams = newExams;
                }
            }
            currentSchedule = DataManager.loadSchedule(halls, hallCount, exams, examCount);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void saveData() {
        try {
            DataManager.saveHalls(halls, hallCount);
            DataManager.saveExams(exams, examCount);
            if (currentSchedule != null) DataManager.saveSchedule(currentSchedule);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving data: " + e.getMessage());
        }
    }

    private void initUI() {
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        mainPanel.setBackground(new Color(245, 248, 250));

        JTabbedPane tabbedPane = new JTabbedPane();
        tabbedPane.setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabbedPane.setBackground(new Color(230, 240, 250));
        tabbedPane.addTab(" Exam Halls", createHallsPanel());
        tabbedPane.addTab(" Course Exams", createExamsPanel());
        tabbedPane.addTab(" Constraints", createConstraintsPanel());
        tabbedPane.addTab(" Scheduler", createSchedulerPanel());

        mainPanel.add(tabbedPane, BorderLayout.CENTER);

        // Status bar – store references in instance fields
        JPanel statusPanel = new JPanel(new BorderLayout());
        statusPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        statusPanel.setBackground(new Color(220, 230, 240));
        statusLabel = new JLabel("✅ Ready");
        statusLabel.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        statusLabel.setForeground(new Color(40, 70, 100));
        progressBar = new JProgressBar();
        progressBar.setVisible(false);
        statusPanel.add(statusLabel, BorderLayout.WEST);
        statusPanel.add(progressBar, BorderLayout.EAST);
        mainPanel.add(statusPanel, BorderLayout.SOUTH);

        add(mainPanel);
    }

    // ------------------- Exam Halls Panel -------------------
    private JPanel createHallsPanel() {
    	JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(new Color(245, 248, 250));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // List of halls with custom cell renderer
        DefaultListModel<String> listModel = new DefaultListModel<>();
        for (int i = 0; i < hallCount; i++)
            listModel.addElement(halls[i].getName() + "  | Capacity: " + halls[i].getCapacity());
        JList<String> hallList = new JList<>(listModel);
        hallList.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        hallList.setBackground(Color.WHITE);
        hallList.setBorder(BorderFactory.createLineBorder(new Color(180, 200, 220), 1));
        JScrollPane listScroll = new JScrollPane(hallList);
        listScroll.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(150, 180, 210), 1),
                "Registered Halls", TitledBorder.LEFT, TitledBorder.TOP, new Font("Segoe UI", Font.BOLD, 12), new Color(50, 90, 150)));
        panel.add(listScroll, BorderLayout.CENTER);

        // Input panel using GridBagLayout for neat form
        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBackground(new Color(245, 248, 250));
        inputPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder("➕ Add New Hall"),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        inputPanel.add(new JLabel("Hall Name:"), gbc);
        JTextField nameField = new JTextField(15);
        nameField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        gbc.gridx = 1;
        inputPanel.add(nameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        inputPanel.add(new JLabel("Capacity:"), gbc);
        JTextField capField = new JTextField(10);
        capField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        gbc.gridx = 1;
        inputPanel.add(capField, gbc);

        JButton addBtn = new JButton("➕ Add Hall");
        addBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        addBtn.setBackground(new Color(70, 130, 180));
        addBtn.setForeground(Color.WHITE);
        addBtn.setFocusPainted(false);
        addBtn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
       
		addBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            if (!name.isEmpty()) {
                try {
                    int cap = Integer.parseInt(capField.getText().trim());
                    if (hallCount == halls.length) {
                        ExamHall[] newHalls = new ExamHall[halls.length + 10];
                        for (int i = 0; i < hallCount; i++) newHalls[i] = halls[i];
                        halls = newHalls;
                    }
                    halls[hallCount++] = new ExamHall(name, cap);
                    listModel.addElement( name + "  |  Capacity: " + cap);
                    nameField.setText("");
                    capField.setText("");
                    saveData();
                    statusLabel.setText("✅ Hall added: " + name);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(panel, "Please enter a valid number for capacity.", "Input Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        });
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        inputPanel.add(addBtn, gbc);

        // Delete button
        JButton delBtn = new JButton("Delete Selected");
        delBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        delBtn.setBackground(new Color(200, 70, 70));
        delBtn.setForeground(Color.WHITE);
        delBtn.setFocusPainted(false);
        delBtn.addActionListener(e -> {
            int idx = hallList.getSelectedIndex();
            if (idx >= 0 && idx < hallCount) {
                for (int i = idx; i < hallCount - 1; i++) halls[i] = halls[i + 1];
                hallCount--;
                listModel.remove(idx);
                saveData();
                statusLabel.setText("Hall deleted");
            } else {
                JOptionPane.showMessageDialog(panel, "Please select a hall to delete.", "No Selection", JOptionPane.WARNING_MESSAGE);
            }
        });

        JPanel southPanel = new JPanel(new BorderLayout(10, 10));
        southPanel.add(inputPanel, BorderLayout.NORTH);
        southPanel.add(delBtn, BorderLayout.CENTER);
        panel.add(southPanel, BorderLayout.SOUTH);

        return panel;
    }

    // ------------------- Course Exams Panel -------------------
    private JPanel createExamsPanel() {
    	JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBackground(new Color(245, 248, 250));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        DefaultListModel<String> listModel = new DefaultListModel<>();
        for (int i = 0; i < examCount; i++)
            listModel.addElement(exams[i].getCourseName() + "  |  " + exams[i].getStudentCount() + " students  | " + exams[i].getDuration() + " periods");
        JList<String> examList = new JList<>(listModel);
        examList.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        JScrollPane listScroll = new JScrollPane(examList);
        listScroll.setBorder(BorderFactory.createTitledBorder("Registered Exams"));
        panel.add(listScroll, BorderLayout.CENTER);

        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBorder(BorderFactory.createTitledBorder("➕ Add New Exam"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        gbc.gridx = 0; gbc.gridy = 0;
        inputPanel.add(new JLabel("Course Name:"), gbc);
        JTextField nameField = new JTextField(15);
        gbc.gridx = 1;
        inputPanel.add(nameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        inputPanel.add(new JLabel("# Students:"), gbc);
        JTextField studField = new JTextField(10);
        gbc.gridx = 1;
        inputPanel.add(studField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        inputPanel.add(new JLabel("Duration (1-5 periods):"), gbc);
        JTextField durField = new JTextField(5);
        gbc.gridx = 1;
        inputPanel.add(durField, gbc);

        JButton addBtn = new JButton("➕ Add Exam");
        addBtn.setBackground(new Color(70, 130, 180));
        addBtn.setForeground(Color.WHITE);
        addBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        addBtn.addActionListener(e -> {
            String name = nameField.getText().trim();
            if (name.isEmpty()) return;
            try {
                int stud = Integer.parseInt(studField.getText().trim());
                int dur = Integer.parseInt(durField.getText().trim());
                if (dur < 1 || dur > 5) throw new NumberFormatException();
                CourseExam exam = new CourseExam(name, stud, dur);
                if (examCount == exams.length) {
                    CourseExam[] newExams = new CourseExam[exams.length + 10];
                    for (int i = 0; i < examCount; i++) newExams[i] = exams[i];
                    exams = newExams;
                }
                exams[examCount++] = exam;
                listModel.addElement(name + "  | " + stud + " students  |  " + dur + " periods");
                nameField.setText("");
                studField.setText("");
                durField.setText("");
                saveData();
                statusLabel.setText("✅ Exam added: " + name);  // use instance field
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(panel, "Invalid input. Duration must be 1-5.", "Input Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        inputPanel.add(addBtn, gbc);

        JButton delBtn = new JButton("Delete Selected");
        delBtn.setBackground(new Color(200, 70, 70));
        delBtn.setForeground(Color.WHITE);
        delBtn.addActionListener(e -> {
            int idx = examList.getSelectedIndex();
            if (idx >= 0 && idx < examCount) {
                for (int i = idx; i < examCount - 1; i++) exams[i] = exams[i + 1];
                examCount--;
                listModel.remove(idx);
                saveData();
                statusLabel.setText("🗑️ Exam deleted");
            }
        });

        JPanel southPanel = new JPanel(new BorderLayout(10, 10));
        southPanel.add(inputPanel, BorderLayout.NORTH);
        southPanel.add(delBtn, BorderLayout.CENTER);
        panel.add(southPanel, BorderLayout.SOUTH);
        return panel;
    }

    // ------------------- Constraints Panel -------------------
    private JPanel createConstraintsPanel() {
    	 JPanel panel = new JPanel(new BorderLayout(10, 10));
         panel.setBackground(new Color(245, 248, 250));
         panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

         DefaultListModel<String> consModel = new DefaultListModel<>();
         for (int i = 0; i < constraintCount; i++) {
             consModel.addElement("🔒 " + extraConstraints[i].getClass().getSimpleName());
         }
         JList<String> consList = new JList<>(consModel);
         consList.setFont(new Font("Segoe UI", Font.PLAIN, 13));
         JScrollPane listScroll = new JScrollPane(consList);
         listScroll.setBorder(BorderFactory.createTitledBorder("📌 Active Constraints"));
         panel.add(listScroll, BorderLayout.CENTER);

         JButton addPrefSlot = new JButton("⭐ Add Preferred Time Slot");
         addPrefSlot.setFont(new Font("Segoe UI", Font.BOLD, 12));
         addPrefSlot.setBackground(new Color(100, 160, 100));
         addPrefSlot.setForeground(Color.WHITE);
         addPrefSlot.setToolTipText("Force an exam to be scheduled at a specific day and period");
         addPrefSlot.addActionListener(e -> {
             if (examCount == 0) {
                 JOptionPane.showMessageDialog(panel, "No exams exist. Create exams first.");
                 return;
             }
             String[] examNames = new String[examCount];
             for (int i = 0; i < examCount; i++) examNames[i] = exams[i].getCourseName();
             String selectedName = (String) JOptionPane.showInputDialog(panel, "Select exam:", "Preferred Slot",
                     JOptionPane.QUESTION_MESSAGE, null, examNames, examNames[0]);
             if (selectedName != null) {
                 CourseExam selectedExam = null;
                 for (int i = 0; i < examCount; i++)
                     if (exams[i].getCourseName().equals(selectedName)) selectedExam = exams[i];
                 if (selectedExam == null) return;
                 String[] days = {"Monday (0)", "Tuesday (1)", "Wednesday (2)", "Thursday (3)", "Friday (4)"};
                 String[] periods = {"8:00 (0)", "9:00 (1)", "10:00 (2)", "11:00 (3)", "12:00 (4)"};
                 int day = JOptionPane.showOptionDialog(panel, "Select day:", "Day", JOptionPane.DEFAULT_OPTION,
                         JOptionPane.QUESTION_MESSAGE, null, days, days[0]);
                 if (day == JOptionPane.CLOSED_OPTION) return;
                 int period = JOptionPane.showOptionDialog(panel, "Select start period:", "Period", JOptionPane.DEFAULT_OPTION,
                         JOptionPane.QUESTION_MESSAGE, null, periods, periods[0]);
                 if (period == JOptionPane.CLOSED_OPTION) return;
                 // Use correct class name: TimeSlot (not Timeslot)
                 Timeslot slot = new Timeslot(day, period);
                 Timeslot[] prefArray = new Timeslot[1];
                 prefArray[0] = slot;
                 PreferredSlotConstraint pc = new PreferredSlotConstraint(selectedExam, prefArray, 1);
                 if (constraintCount == extraConstraints.length) {
                     Constraint[] newArr = new Constraint[extraConstraints.length + 10];
                     for (int i = 0; i < constraintCount; i++) newArr[i] = extraConstraints[i];
                     extraConstraints = newArr;
                 }
                 extraConstraints[constraintCount++] = pc;
                 consModel.addElement("⭐ Preferred slot: " + selectedExam.getCourseName() + " @ " + slot);
                 statusLabel.setText("⭐ Constraint added");  // use instance field
             }
         });
         panel.add(addPrefSlot, BorderLayout.SOUTH);
         return panel;   
         }

    // ------------------- Scheduler Panel -------------------
    private JPanel createSchedulerPanel() {
    	 JPanel panel = new JPanel(new BorderLayout(10, 10));
         panel.setBackground(new Color(245, 248, 250));
         panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

         JButton runBtn = new JButton("Run Scheduler");
         runBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
         runBtn.setBackground(new Color(50, 150, 80));
         runBtn.setForeground(Color.WHITE);
         runBtn.setFocusPainted(false);
         runBtn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

         JButton exportBtn = new JButton("Export Schedule as HTML");
         exportBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
         exportBtn.setBackground(new Color(70, 110, 150));
         exportBtn.setForeground(Color.WHITE);
         exportBtn.setFocusPainted(false);
         exportBtn.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

         JPanel topPanel = new JPanel();
         topPanel.add(runBtn);
         topPanel.add(exportBtn);
         panel.add(topPanel, BorderLayout.NORTH);

         scheduleModel = new DefaultTableModel();
         scheduleTable = new JTable(scheduleModel);
         JScrollPane tableScroll = new JScrollPane(scheduleTable);
         tableScroll.setBorder(BorderFactory.createTitledBorder("📅 Generated Schedule"));
         panel.add(tableScroll, BorderLayout.CENTER);

         runBtn.addActionListener(e -> runScheduler());
         exportBtn.addActionListener(e -> exportToHTML());
         return panel;
    }

    private void runScheduler() {
    	if (hallCount == 0 || examCount == 0) {
            JOptionPane.showMessageDialog(this, "Please add at least one hall and one exam.", "Missing Data", JOptionPane.WARNING_MESSAGE);
            return;
        }
        // Use the instance fields
        progressBar.setVisible(true);
        progressBar.setIndeterminate(true);
        statusLabel.setText("⏳ Scheduling in progress...");

        SwingWorker<ExamSchedule, Void> worker = new SwingWorker<>() {
            @Override
            protected ExamSchedule doInBackground() throws Exception {
                ExamHall[] hallsCopy = new ExamHall[hallCount];
                for (int i = 0; i < hallCount; i++) hallsCopy[i] = halls[i];
                CourseExam[] examsCopy = new CourseExam[examCount];
                for (int i = 0; i < examCount; i++) examsCopy[i] = exams[i];
                ExamScheduler scheduler = new ExamScheduler(hallsCopy, hallCount, examsCopy, examCount);
                for (int i = 0; i < constraintCount; i++) scheduler.addConstraint(extraConstraints[i]);
                return scheduler.schedule();
            }
            @Override
            protected void done() {
                progressBar.setVisible(false);
                try {
                    currentSchedule = get();
                    saveData();
                    displaySchedule();
                    statusLabel.setText("✅ Schedule generated successfully!");
                    JOptionPane.showMessageDialog(SchedulingGUI.this, "Schedule generated!", "Success", JOptionPane.INFORMATION_MESSAGE);
                } catch (Exception ex) {
                    if (ex.getCause() instanceof UnschedulableException) {
                        statusLabel.setText("❌ Scheduling failed: " + ex.getCause().getMessage());
                        JOptionPane.showMessageDialog(SchedulingGUI.this, "Scheduling failed: " + ex.getCause().getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    } else {
                        statusLabel.setText("❌ Unexpected error");
                        ex.printStackTrace();
                        JOptionPane.showMessageDialog(SchedulingGUI.this, "Unexpected error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        };
        worker.execute();
    }

    private void displaySchedule() {
    	if (currentSchedule == null) return;

        // Column headers (5 days × 5 periods)
        String[] days = {"Mon", "Tue", "Wed", "Thu", "Fri"};
        String[] times = {"8:00", "9:00", "10:00", "11:00", "12:00"};
        String[] colNames = new String[25];
        for (int d = 0; d < 5; d++)
            for (int p = 0; p < 5; p++)
                colNames[d * 5 + p] = days[d] + " " + times[p];

        scheduleModel.setColumnIdentifiers(colNames);
        scheduleModel.setRowCount(hallCount);

        // Clear all cells
        for (int r = 0; r < hallCount; r++)
            for (int c = 0; c < 25; c++)
                scheduleModel.setValueAt("", r, c);

        // Store exam names for each cell (to be used by renderer)
        String[][] cellExamNames = new String[hallCount][25];
        for (int r = 0; r < hallCount; r++)
            for (int c = 0; c < 25; c++)
                cellExamNames[r][c] = "";

        // Fill assignments into both the model and the cellExamNames array
        for (int i = 0; i < currentSchedule.getSize(); i++) {
            CourseExam exam = currentSchedule.getExam(i);
            Assignment ass = currentSchedule.getAssignmentAt(i);
            ExamHall hall = ass.getHall();

            int hallIdx = -1;
            for (int j = 0; j < hallCount; j++)
                if (halls[j] == hall) { hallIdx = j; break; }
            if (hallIdx == -1) continue;

            Timeslot start = ass.getStartSlot();
            int day = start.getDayIndex();
            int startP = start.getPeriodIndex();
            int dur = ass.getDuration();
            String examName = exam.getCourseName();

            for (int p = 0; p < dur; p++) {
                int col = day * 5 + startP + p;
                String existing = (String) scheduleModel.getValueAt(hallIdx, col);
                String newVal = existing.isEmpty() ? examName : existing + "," + examName;
                scheduleModel.setValueAt(newVal, hallIdx, col);
                // Store the first exam name for colour coding (if multiple, we use the first)
                if (cellExamNames[hallIdx][col].isEmpty())
                    cellExamNames[hallIdx][col] = examName;
                else
                    cellExamNames[hallIdx][col] = "MIXED";
            }
        }

        // Apply alternating row colors (via custom renderer)
        scheduleTable.setDefaultRenderer(Object.class, new javax.swing.table.TableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                JLabel label = new JLabel(value != null ? value.toString() : "");
                label.setOpaque(true);
                label.setFont(new Font("Segoe UI", Font.PLAIN, 12));
                label.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
                label.setHorizontalAlignment(SwingConstants.CENTER);

                // Background colour based on exam name
                String examName = cellExamNames[row][column];
                if (examName != null && !examName.isEmpty() && !examName.equals("MIXED")) {
                    label.setBackground(getExamColor(examName));
                } else if ("MIXED".equals(examName)) {
                    label.setBackground(new Color(255, 200, 200)); // light red for overlaps (should not happen)
                } else {
                    label.setBackground(row % 2 == 0 ? Color.WHITE : new Color(245, 250, 255));
                }

                // Foreground colour
                label.setForeground(Color.BLACK);

                // Tooltip: show exam details
                if (examName != null && !examName.isEmpty() && !examName.equals("MIXED")) {
                    // Find the exam object to get details
                    for (int i = 0; i < currentSchedule.getSize(); i++) {
                        CourseExam e = currentSchedule.getExam(i);
                        if (e.getCourseName().equals(examName)) {
                            Assignment a = currentSchedule.getAssignmentAt(i);
                            label.setToolTipText("<html><b>" + e.getCourseName() + "</b><br>"
                                    + "Students: " + e.getStudentCount() + "<br>"
                                    + "Hall: " + a.getHall().getName() + "<br>"
                                    + "Duration: " + e.getDuration() + " periods</html>");
                            break;
                        }
                    }
                } else {
                    label.setToolTipText(null);
                }

                if (isSelected) {
                    label.setBackground(new Color(180, 210, 240));
                }
                return label;
            }

			private Color getExamColor(String examName) {
				// TODO Auto-generated method stub
				return null;
			}
        });
        scheduleTable.setRowHeight(40);
        for (int col = 0; col < scheduleTable.getColumnCount(); col++) {
            scheduleTable.getColumnModel().getColumn(col).setPreferredWidth(90);
        }
        // Make first column (hall name) a bit wider
        scheduleTable.getColumnModel().getColumn(0).setPreferredWidth(120);
    }

    private void exportToHTML() {
    	 if (currentSchedule == null || scheduleTable.getRowCount() == 0) {
    	        JOptionPane.showMessageDialog(this, "No schedule to export. Run scheduler first.", "Export Error", JOptionPane.WARNING_MESSAGE);
    	        return;
    	    }

    	    // Build colour mapping for exams (same pastel logic as in GUI)
    	    // First collect all exam names from the schedule
    	    String[] examNames = new String[currentSchedule.getSize()];
    	    for (int i = 0; i < currentSchedule.getSize(); i++) {
    	        examNames[i] = currentSchedule.getExam(i).getCourseName();
    	    }
    	    // We'll generate a colour for each unique exam using the same getExamColor logic
    	    // Since we can't call the method from HTML, we'll generate CSS classes inline

    	    // Create a mapping from exam name to colour (hex)
    	    java.util.HashMap<String, String> colourMap = new java.util.HashMap<>(); // temporary for HTML generation only
    	    for (String name : examNames) {
    	        if (!colourMap.containsKey(name)) {
    	            int hash = name.hashCode();
    	            float hue = (Math.abs(hash) % 360) / 360f;
    	            java.awt.Color col = java.awt.Color.getHSBColor(hue, 0.6f, 0.9f);
    	            String hex = String.format("#%02x%02x%02x", col.getRed(), col.getGreen(), col.getBlue());
    	            colourMap.put(name, hex);
    	        }
    	    }

    	    // Prepare data: for each cell we need the exam name (first one if multiple)
    	    String[][] cellExam = new String[hallCount][25];
    	    for (int r = 0; r < hallCount; r++)
    	        for (int c = 0; c < 25; c++)
    	            cellExam[r][c] = "";

    	    for (int i = 0; i < currentSchedule.getSize(); i++) {
    	        CourseExam exam = currentSchedule.getExam(i);
    	        Assignment ass = currentSchedule.getAssignmentAt(i);
    	        ExamHall hall = ass.getHall();
    	        int hallIdx = -1;
    	        for (int j = 0; j < hallCount; j++) if (halls[j] == hall) { hallIdx = j; break; }
    	        if (hallIdx == -1) continue;
    	        Timeslot start = ass.getStartSlot();
    	        int day = start.getDayIndex();
    	        int startP = start.getPeriodIndex();
    	        int dur = ass.getDuration();
    	        for (int p = 0; p < dur; p++) {
    	            int col = day * 5 + startP + p;
    	            if (cellExam[hallIdx][col].isEmpty())
    	                cellExam[hallIdx][col] = exam.getCourseName();
    	            else
    	                cellExam[hallIdx][col] = "MIXED";
    	        }
    	    }

    	    // Build HTML
    	    StringBuilder html = new StringBuilder();
    	    html.append("<!DOCTYPE html>\n");
    	    html.append("<html lang=\"en\">\n<head>\n");
    	    html.append("<meta charset=\"UTF-8\">\n");
    	    html.append("<meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n");
    	    html.append("<title>Exam Schedule</title>\n");
    	    html.append("<style>\n");
    	    html.append("body { font-family: 'Segoe UI', Arial, sans-serif; background: #f5f7fa; margin: 0; padding: 20px; }\n");
    	    html.append(".container { max-width: 1400px; margin: 0 auto; background: white; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); overflow-x: auto; }\n");
    	    html.append("h2 { text-align: center; color: #2c6e9e; padding: 20px 0 0 0; margin: 0; }\n");
    	    html.append(".subtitle { text-align: center; color: #555; font-size: 14px; margin-bottom: 20px; }\n");
    	    html.append("table { width: 100%; border-collapse: collapse; font-size: 13px; }\n");
    	    html.append("th, td { border: 1px solid #ddd; padding: 10px 8px; text-align: center; vertical-align: middle; }\n");
    	    html.append("th { background-color: #2c6e9e; color: white; font-weight: bold; position: sticky; top: 0; }\n");
    	    html.append("tr:nth-child(even) td { background-color: #f9f9f9; }\n");
    	    html.append("td:hover { filter: brightness(0.95); cursor: pointer; }\n");
    	    html.append(".hall-col { background-color: #e8f0f8 !important; font-weight: bold; text-align: left; position: sticky; left: 0; background: #e8f0f8; }\n");
    	    html.append(".legend { display: flex; flex-wrap: wrap; justify-content: center; gap: 15px; padding: 15px; background: #f0f2f5; border-radius: 8px; margin-bottom: 20px; }\n");
    	    html.append(".legend-item { display: flex; align-items: center; gap: 6px; font-size: 12px; }\n");
    	    html.append(".legend-color { width: 20px; height: 20px; border-radius: 4px; border: 1px solid #ccc; }\n");
    	    html.append(".tooltip { cursor: help; }\n");
    	    html.append("</style>\n");
    	    html.append("</head>\n<body>\n");
    	    html.append("<div class=\"container\">\n");
    	    html.append("<h2>📅 University Exam Schedule</h2>\n");
    	    html.append("<div class=\"subtitle\">Generated on " + new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date()) + "</div>\n");

    	    // Legend
    	    html.append("<div class=\"legend\">\n");
    	    for (String name : colourMap.keySet()) {
    	        html.append("<div class=\"legend-item\">\n");
    	        html.append("<div class=\"legend-color\" style=\"background-color: " + colourMap.get(name) + ";\"></div>\n");
    	        html.append("<span>" + escapeHtml(name) + "</span>\n");
    	        html.append("</div>\n");
    	    }
    	    html.append("</div>\n");

    	    // Table header
    	    String[] days = {"Mon", "Tue", "Wed", "Thu", "Fri"};
    	    String[] times = {"8:00", "9:00", "10:00", "11:00", "12:00"};
    	    html.append("<table>\n");
    	    html.append("<thead>\n<tr><th>Hall / Time</th>");
    	    for (int d = 0; d < 5; d++) {
    	        for (int p = 0; p < 5; p++) {
    	            html.append("<th>" + days[d] + "<br>" + times[p] + "</th>");
    	        }
    	    }
    	    html.append("</tr></thead>\n<tbody>\n");

    	    // Table rows (each hall)
    	    for (int r = 0; r < hallCount; r++) {
    	        html.append("<tr>");
    	        html.append("<td class=\"hall-col\">" + escapeHtml(halls[r].getName()) + "</td>");
    	        for (int c = 0; c < 25; c++) {
    	            String examName = cellExam[r][c];
    	            String displayText = examName.isEmpty() ? "—" : examName;
    	            String bgColor = "";
    	            String tooltip = "";
    	            if (!examName.isEmpty() && !examName.equals("MIXED")) {
    	                bgColor = "background-color: " + colourMap.getOrDefault(examName, "#fff") + ";";
    	                // Find exam details for tooltip
    	                for (int i = 0; i < currentSchedule.getSize(); i++) {
    	                    CourseExam e = currentSchedule.getExam(i);
    	                    if (e.getCourseName().equals(examName)) {
    	                        Assignment a = currentSchedule.getAssignmentAt(i);
    	                        tooltip = " title=\"" + escapeHtml(e.getCourseName()) + "\\nStudents: " + e.getStudentCount() +
    	                                  "\\nHall: " + a.getHall().getName() + "\\nDuration: " + e.getDuration() + " periods\"";
    	                        break;
    	                    }
    	                }
    	            } else if (examName.equals("MIXED")) {
    	                bgColor = "background-color: #ffcccc;";
    	                tooltip = " title=\"Multiple exams in same slot (error)\"";
    	            } else {
    	                bgColor = "";
    	            }
    	            html.append("<td style=\"" + bgColor + "\"" + tooltip + " class=\"tooltip\">" + escapeHtml(displayText) + "</td>");
    	        }
    	        html.append("</tr>\n");
    	    }
    	    html.append("</tbody>\n</table>\n");
    	    html.append("</div>\n</body>\n</html>");

    	    try {
    	        java.nio.file.Files.write(java.nio.file.Paths.get("schedule.html"), html.toString().getBytes());
    	        statusLabel.setText("📄 Schedule exported to schedule.html");
    	        JOptionPane.showMessageDialog(this, "Schedule exported to schedule.html", "Export Complete", JOptionPane.INFORMATION_MESSAGE);
    	    } catch (IOException ex) {
    	        JOptionPane.showMessageDialog(this, "Export failed: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    	    }
    	}

    	// Helper to escape HTML special characters
    	private String escapeHtml(String s) {
    	    if (s == null) return "";
    	    return s.replace("&", "&amp;")
    	            .replace("<", "&lt;")
    	            .replace(">", "&gt;")
    	            .replace("\"", "&quot;")
    	            .replace("'", "&#39;");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new SchedulingGUI().setVisible(true));
    }
}