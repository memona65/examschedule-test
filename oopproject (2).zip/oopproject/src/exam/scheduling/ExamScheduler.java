package exam.scheduling;

public class ExamScheduler {
    private ExamHall[] halls;
    private int hallCount;
    private CourseExam[] exams;
    private int examCount;
    private Constraint[] constraints;
    private int constraintCount;

    public ExamScheduler(ExamHall[] halls, int hCount, CourseExam[] exams, int eCount) {
        this.halls = new ExamHall[hCount];
        for (int i = 0; i < hCount; i++) this.halls[i] = halls[i];
        this.hallCount = hCount;
        this.exams = new CourseExam[eCount];
        for (int i = 0; i < eCount; i++) this.exams[i] = exams[i];
        this.examCount = eCount;
        this.constraints = new Constraint[10];
        this.constraintCount = 0;
        // mandatory constraints
        addConstraint(new CapacityConstraint());
        addConstraint(new StudentClashConstraint());
    }

    // Overloaded addConstraint
    public void addConstraint(CapacityConstraint c) { addConstraint((Constraint)c); }
    public void addConstraint(StudentClashConstraint c) { addConstraint((Constraint)c); }
    public void addConstraint(PreferredSlotConstraint c) { addConstraint((Constraint)c); }
    public void addConstraint(Constraint c) {
        if (constraintCount == constraints.length) {
            Constraint[] newArr = new Constraint[constraints.length * 2];
            for (int i = 0; i < constraintCount; i++) newArr[i] = constraints[i];
            constraints = newArr;
        }
        constraints[constraintCount++] = c;
    }

    public ExamSchedule schedule() throws UnschedulableException {
        // sort exams by descending student count (simple bubble sort)
        CourseExam[] sorted = new CourseExam[examCount];
        for (int i = 0; i < examCount; i++) sorted[i] = exams[i];
        for (int i = 0; i < examCount-1; i++)
            for (int j = 0; j < examCount-1-i; j++)
                if (sorted[j].getStudentCount() < sorted[j+1].getStudentCount()) {
                    CourseExam t = sorted[j]; sorted[j] = sorted[j+1]; sorted[j+1] = t;
                }
        ExamSchedule schedule = new ExamSchedule(examCount);
        if (backtrack(0, sorted, schedule)) return schedule;
        throw new UnschedulableException("No feasible schedule");
    }

    private boolean backtrack(int idx, CourseExam[] sortedExams, ExamSchedule schedule) {
        if (idx == examCount) return true;
        CourseExam exam = sortedExams[idx];
        for (int h = 0; h < hallCount; h++) {
            ExamHall hall = halls[h];
            for (int day = 0; day < 5; day++) {
                for (int startP = 0; startP <= 5 - exam.getDuration(); startP++) {
                    Timeslot start = new Timeslot(day, startP);
                    if (isHallAvailable(hall, start, exam.getDuration(), schedule)) {
                        boolean ok = true;
                        for (int c = 0; c < constraintCount; c++) {
                            if (!constraints[c].isSatisfied(exam, hall, start, exam.getDuration(), schedule)) {
                                ok = false; break;
                            }
                        }
                        if (ok) {
                            schedule.assign(exam, new Assignment(hall, start, exam.getDuration()));
                            if (backtrack(idx+1, sortedExams, schedule)) return true;
                            // backtrack: remove last assignment (simplest by resetting schedule size)
                            // schedule size is idx+1, we just decrement later – but we need a way to remove
                            // Instead, we create a fresh schedule copy? Too heavy. Better: implement schedule.removeLast()
                            // Simpler: use an array of assignments and keep size; we already have size in schedule.
                            // We'll add a removeLast() method.
                            schedule.removeLast();
                        }
                    }
                }
            }
        }
        return false;
    }

    private boolean isHallAvailable(ExamHall hall, Timeslot start, int duration, ExamSchedule schedule) {
        int day = start.getDayIndex();
        int startP = start.getPeriodIndex();
        int endP = startP + duration - 1;
        for (int i = 0; i < schedule.getSize(); i++) {
            Assignment a = schedule.getAssignmentAt(i);
            if (a.getHall() != hall) continue;
            Timeslot otherStart = a.getStartSlot();
            if (otherStart.getDayIndex() != day) continue;
            int oStart = otherStart.getPeriodIndex();
            int oEnd = oStart + a.getDuration() - 1;
            if (startP <= oEnd && endP >= oStart) return false;
        }
        return true;
    }
    
    
}
